//
//  Constants.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 19.12.2024.
//

import UIKit.UIColor

struct Constants {

    struct URLs {
        static let webSocketEcho = "wss://echo.websocket.org"
    }

    struct Colors {
        static let mainPurpleN11 = UIColor(red: 0.35, green: 0.25, blue: 0.71, alpha: 1.00)
        static let incomingMessageBackground = UIColor(white: 0.90, alpha: 1)
        static let stepButtonBackground = UIColor.lightGray.withAlphaComponent(0.1)
        static let sendingMessageDefaultBackground = UIColor.systemBlue
        static let grayText = UIColor.gray.withAlphaComponent(0.5)
        static let darkText = UIColor.black.withAlphaComponent(0.9)
        static let lightText = UIColor.white
        static let successMessage = UIColor.green.withAlphaComponent(0.9)
        static let failureMessage = UIColor.red.withAlphaComponent(0.9)
    }
}
