//
//  ChatInteractor.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 16.12.2024.
//
import UIKit

protocol LiveSupportInteractorProtocol: AnyObject {
    func connect()
    func disconnect()
    func sendUserMessage(_ text: String)
    func fetchInitialJSON(completion: @escaping ([StepData]) -> Void)
}

protocol LiveSupportInteractorOutput: AnyObject {
    func lastMessageSended(isSuccess: Bool)
    func didReceiveWebSocketEcho(_ text: String)
    func disconnected()
}

final class LiveSupportInteractor: LiveSupportInteractorProtocol {
    
    weak var output: LiveSupportInteractorOutput?
    
    private let webSocketManager = WebSocketManager.shared
    
    init() {
        webSocketManager.delegate = self
    }
    
    func connect() {
        webSocketManager.connectWebSocket()
    }
    
    func disconnect() {
        webSocketManager.disconnect()
    }
    
    func sendUserMessage(_ text: String) {
        webSocketManager.sendMessage(text) { success in
            if !success {
                print("🔴Message sended fail")
                // son mesaj rengini değiştirmek için (success: yeşil - error: kırmızı)
                self.output?.lastMessageSended(isSuccess: false)
            } else {
                print("✅Message sending success")
                // son mesaj rengini değiştirmek için (success: yeşil - error: kırmızı)
                self.output?.lastMessageSended(isSuccess: true)
            }
        }
    }
    
    func fetchInitialJSON(completion: @escaping ([StepData]) -> Void) {
        guard let url = Bundle.main.url(forResource: "FirstChat",
                                        withExtension: "json") else {
            print("🔴FirstChat.json not found.")
            completion([])
            return
        }
        do {
            let data = try Data(contentsOf: url)
            let steps = try JSONDecoder().decode([StepData].self, from: data)
            completion(steps)
        } catch {
            print("🔴Decode error: \(error)")
            completion([])
        }
    }
}

// MARK: - WebSocketManagerDelegate
extension LiveSupportInteractor: WebSocketManagerDelegate {
    func disconnected() {
        output?.disconnected()
    }
    
    func didReceiveMessage(_ text: String) {
        // Echo’dan gelen mesaj -> Presenter’a ilet
        output?.didReceiveWebSocketEcho(text)
    }
}
