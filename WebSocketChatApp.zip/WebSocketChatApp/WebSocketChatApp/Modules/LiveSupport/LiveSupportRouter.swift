//
//  LiveSupportRouter.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 16.12.2024.
//

import UIKit

protocol LiveSupportRouterProtocol: AnyObject {
    static func createModule() -> UIViewController
}

final class LiveSupportRouter: LiveSupportRouterProtocol {
    static func createModule() -> UIViewController {
        let interactor = LiveSupportInteractor()
        let presenter = LiveSupportPresenter(interactor: interactor)
        let view = LiveSupportViewController()
        view.presenter = presenter
        presenter.view = view
        return view
    }
}

