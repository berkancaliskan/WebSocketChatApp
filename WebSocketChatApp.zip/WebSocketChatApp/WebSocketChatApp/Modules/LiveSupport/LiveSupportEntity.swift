//
//  LiveSupportEntity.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 16.12.2024.
//
import Foundation

struct StepData: Codable {
    let step: String
    let type: String
    let action: String
    let content: ContentContainer
}

struct ContentContainer: Codable {
    let text: String?
    let buttons: [ButtonItem]?
    let rawString: String?
    
    init(text: String?, buttons: [ButtonItem]?, rawString: String?) {
        self.text = text
        self.buttons = buttons
        self.rawString = rawString
    }
    
    // Custom decoder: content bazen dictionary, bazen string
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        // Eğer content bir dictionary ise
        if let dict = try? container.decode([String: AnyCodable].self) {
            // dict["text"] varsa text al
            let textValue = dict["text"]?.value as? String
            var buttonsValue: [ButtonItem]? = nil
            
            // buttons varsa decode et
            if let btnArray = dict["buttons"]?.value as? [[String: Any]] {
                let data = try JSONSerialization.data(withJSONObject: btnArray, options: [])
                buttonsValue = try JSONDecoder().decode([ButtonItem].self, from: data)
            }
            
            self.init(text: textValue, buttons: buttonsValue, rawString: nil)
        }
        // Eğer content düz bir string ise
        else if let strValue = try? container.decode(String.self) {
            self.init(text: nil, buttons: nil, rawString: strValue)
        } else {
            // Hiçbirine uymuyorsa boş init
            self.init(text: nil, buttons: nil, rawString: nil)
        }
    }
}

// Yardımcı struct (AnyCodable) dictionary decode etmek için
struct AnyCodable: Decodable {
    let value: Any
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let str = try? container.decode(String.self) {
            value = str
        } else if let boolVal = try? container.decode(Bool.self) {
            value = boolVal
        } else if let intVal = try? container.decode(Int.self) {
            value = intVal
        } else if let doubleVal = try? container.decode(Double.self) {
            value = doubleVal
        } else if let dict = try? container.decode([String: AnyCodable].self) {
            value = dict.mapValues { $0.value }
        } else if let arr = try? container.decode([AnyCodable].self) {
            value = arr.map { $0.value }
        } else {
            throw DecodingError.typeMismatch(AnyCodable.self,
                DecodingError.Context(codingPath: decoder.codingPath,
                                      debugDescription: "Unsupported type"))
        }
    }
}


struct ButtonItem: Codable {
    let label: String
    let action: String
}

struct UserMessage {
    let text: String
    let isIncoming: Bool // sağa veya sola yaslı olması için
    var status: MessageStatus? = .sending // gönderim durumunu kontrol edip default mavi rengi, yeşil veya kırmızı yapmak için ekledim.
}

enum MessageStatus {
    case sending
    case success
    case failed
}
