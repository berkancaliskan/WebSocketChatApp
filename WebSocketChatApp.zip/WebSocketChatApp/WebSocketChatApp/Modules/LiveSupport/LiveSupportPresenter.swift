//
//  ChatPresenter.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 16.12.2024.
//
import Foundation

protocol LiveSupportPresenterProtocol: AnyObject {
    var view: LiveSupportViewProtocol? { get set }
    func viewDidLoad()
    func numberOfRows() -> Int
    func cellData(at index: Int) -> Any  // StepData veya UserMessage
    func didTapSend(text: String?)
    func didSelectButton(action: String, message: String)
    func userClosedEndAlert()
    func didTapReconnect()
}

final class LiveSupportPresenter: LiveSupportPresenterProtocol {
    
    weak var view: LiveSupportViewProtocol?
    private let interactor: LiveSupportInteractor
    private var chatItems: [Any] = []
    
    init(interactor: LiveSupportInteractor) {
        self.interactor = interactor
    }
    
    func viewDidLoad() {
        interactor.output = self
        interactor.connect()
        
        // Hardcoded json file'dan ilk mesajları ekle.
        interactor.fetchInitialJSON { [weak self] steps in
            guard let self else { return }
            self.chatItems.append(contentsOf: steps)
            self.view?.reloadData()
        }
    }
    
    func numberOfRows() -> Int {
        return chatItems.count
    }
    
    func cellData(at index: Int) -> Any {
        return chatItems[index]
    }
    
    func didTapSend(text: String?) {
        guard let text = text, !text.isEmpty else { return }
        // Tabloda userMessage olarak ekledim başarılı olunca yeşil olmazsa kırmızı olacak.
        let userMsg = UserMessage(text: text, isIncoming: false)
        chatItems.append(userMsg)
        view?.reloadData()
        view?.clearTextField()
        view?.scrollToBottom()
        
        // websocket'e gönder
        interactor.sendUserMessage(text)
    }
    
    func didSelectButton(action: String, message: String) {
        switch action {
        case "end_conversation":
            interactor.disconnect()
            view?.showEndConversationAlert()
        default:
            //mesaj olarak seçilen action ve mesajı ekledim burada faklı case'ler değerlendirilebilir.
            let userMsg = UserMessage(text: action + " | " + message , isIncoming: false)
            chatItems.append(userMsg)
            view?.reloadData()
            view?.clearTextField()
            view?.scrollToBottom()
            
            interactor.sendUserMessage(action)
        }
    }
    
    func userClosedEndAlert() {
        self.view?.showDisconnectedUI()
    }
    
    func didTapReconnect() {
        interactor.connect()
    }
}

// MARK: - ChatInteractorOutput
extension LiveSupportPresenter: LiveSupportInteractorOutput {
    func disconnected() {
        view?.showDisconnectedUI()
    }
    
    func lastMessageSended(isSuccess: Bool) {
        guard let lastIndex = chatItems.indices.last else { return }
        if var message = chatItems[lastIndex] as? UserMessage {
            message.status = isSuccess ? .success : .failed
            chatItems[lastIndex] = message
        }
        view?.lastMessageSended(isSuccess: isSuccess)
    }

    func didReceiveWebSocketEcho(_ text: String) {
        view?.hideDisconnectedUI()
        let echoMessage = UserMessage(text: text, isIncoming: true)
        chatItems.append(echoMessage)
        view?.reloadData()
        view?.scrollToBottom()
    }
}
