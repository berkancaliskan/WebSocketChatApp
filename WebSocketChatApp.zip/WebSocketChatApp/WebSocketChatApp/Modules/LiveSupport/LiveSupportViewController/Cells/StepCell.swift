//
//  StepCell.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 16.12.2024.
//

import UIKit

import UIKit

class StepCell: UITableViewCell {
    private let dataTextLabel = UILabel()
    private let buttonStack = UIStackView()
    private let customImageView = UIImageView()
    private let verticalStack = UIStackView()
    private var aspectRatioConstraint: NSLayoutConstraint?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setCell()
    }
    
    private func setCell() {
        
        self.selectionStyle = .none
        
        dataTextLabel.numberOfLines = 0
        
        buttonStack.axis = .vertical
        buttonStack.spacing = 8
        
        customImageView.contentMode = .scaleAspectFit
        customImageView.clipsToBounds = true
        
        verticalStack.axis = .vertical
        verticalStack.spacing = 8
        verticalStack.translatesAutoresizingMaskIntoConstraints = false
        
        verticalStack.addArrangedSubview(dataTextLabel)
        verticalStack.addArrangedSubview(buttonStack)
        verticalStack.addArrangedSubview(customImageView)
        
        contentView.addSubview(verticalStack)
        
        NSLayoutConstraint.activate([
            verticalStack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            verticalStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            verticalStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            verticalStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8)
        ])
        
        aspectRatioConstraint = customImageView.heightAnchor.constraint(equalTo: customImageView.widthAnchor, multiplier: 0.75)
        aspectRatioConstraint?.priority = UILayoutPriority(999)
        aspectRatioConstraint?.isActive = false // Başlangıçta kapalı, image olduğunda açılıyor.
        
        dataTextLabel.isHidden = false
        buttonStack.isHidden = true
        customImageView.isHidden = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(stepData: StepData, presenter: LiveSupportPresenterProtocol) {
        dataTextLabel.isHidden = false
        buttonStack.isHidden = true
        customImageView.isHidden = true
        customImageView.image = nil
        aspectRatioConstraint?.isActive = false
        
        switch stepData.type {
        case "button":
            dataTextLabel.text = stepData.content.text
            buttonStack.isHidden = false
            buttonStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
            
            if let buttons = stepData.content.buttons {
                for button in buttons {
                    let newButton = UIButton(type: .system)
                    newButton.backgroundColor = Constants.Colors.stepButtonBackground
                    newButton.setTitle(button.label, for: .normal)
                    newButton.setTitleColor(Constants.Colors.mainPurpleN11, for: .normal)
                    newButton.titleLabel?.textAlignment = .center
                    newButton.layer.cornerRadius = 6
                    newButton.layer.borderWidth = 0.5
                    newButton.layer.borderColor = Constants.Colors.mainPurpleN11.cgColor
                    newButton.addAction(UIAction(handler: { _ in
                        presenter.didSelectButton(action: button.action, message: button.label)
                    }), for: .touchUpInside)
                    buttonStack.addArrangedSubview(newButton)
                }
            }
            
        case "text":
            dataTextLabel.text = stepData.content.rawString
            buttonStack.isHidden = true
            customImageView.isHidden = true
            
        case "image":
            dataTextLabel.isHidden = true
            buttonStack.isHidden = true
            customImageView.isHidden = false
            aspectRatioConstraint?.isActive = true
            if let urlString = stepData.content.rawString, let url = URL(string: urlString) {
                URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
                    guard let self, let data = data, let image = UIImage(data: data) else { return }
                    DispatchQueue.main.async {
                        self.customImageView.image = image
                       
                         let ratio = image.size.height / image.size.width
                         self.aspectRatioConstraint?.isActive = false
                         self.aspectRatioConstraint = self.customImageView.heightAnchor.constraint(equalTo: self.customImageView.widthAnchor, multiplier: ratio)
                         self.aspectRatioConstraint?.priority = UILayoutPriority(999)
                         self.aspectRatioConstraint?.isActive = true
                        
                        self.setNeedsLayout()
                        self.layoutIfNeeded()
                    }
                }.resume()
            }
        default:
            dataTextLabel.text = "[Unknown Type]"
            buttonStack.isHidden = true
            customImageView.isHidden = true
        }
    }
}
