//
//  MessageCell.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 18.12.2024.
//

import UIKit

class MessageCell: UITableViewCell {
    
    private let messageLabel = UILabel()
    private let bubbleBackground = UIView()
    
    private var leadingConstraint: NSLayoutConstraint!
    private var trailingConstraint: NSLayoutConstraint!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupCell()
    }
    
    func setupCell() {
        
        self.selectionStyle = .none
        
        bubbleBackground.translatesAutoresizingMaskIntoConstraints = false
        bubbleBackground.layer.cornerRadius = 14
        bubbleBackground.layer.masksToBounds = true
        contentView.addSubview(bubbleBackground)
        
        messageLabel.numberOfLines = 0
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(messageLabel)
        
        // Constraints
        let constraints = [
            messageLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            messageLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
            messageLabel.widthAnchor.constraint(lessThanOrEqualToConstant: 250),
            
            bubbleBackground.topAnchor.constraint(equalTo: messageLabel.topAnchor, constant: -8),
            bubbleBackground.leadingAnchor.constraint(equalTo: messageLabel.leadingAnchor, constant: -8),
            bubbleBackground.bottomAnchor.constraint(equalTo: messageLabel.bottomAnchor, constant: 8),
            bubbleBackground.trailingAnchor.constraint(equalTo: messageLabel.trailingAnchor, constant: 8)
        ]
        NSLayoutConstraint.activate(constraints)
        
        leadingConstraint = messageLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16)
        trailingConstraint = messageLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16)
        
        leadingConstraint.isActive = false
        trailingConstraint.isActive = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(message: UserMessage) {
        messageLabel.text = message.text
        
        if message.isIncoming {
            // Gelen mesaj -> sol
            messageLabel.textColor = Constants.Colors.darkText
            bubbleBackground.backgroundColor = Constants.Colors.incomingMessageBackground
            leadingConstraint.isActive = true
            trailingConstraint.isActive = false
        } else {
            // Giden mesaj -> sağ
            messageLabel.textColor = Constants.Colors.lightText
            switch message.status {
            case .sending:
                bubbleBackground.backgroundColor = Constants.Colors.sendingMessageDefaultBackground
            case .success:
                bubbleBackground.backgroundColor = Constants.Colors.successMessage
            case .failed:
                bubbleBackground.backgroundColor = Constants.Colors.failureMessage
            default:
                bubbleBackground.backgroundColor = Constants.Colors.sendingMessageDefaultBackground
            }
            leadingConstraint.isActive = false
            trailingConstraint.isActive = true
            
        }
    }
}
