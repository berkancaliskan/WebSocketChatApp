//
//  LiveSupportViewController.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 16.12.2024.
//

import UIKit

protocol LiveSupportViewProtocol: AnyObject {
    func reloadData()
    func clearTextField()
    func scrollToBottom()
    func showEndConversationAlert()
    func lastMessageSended(isSuccess: Bool)
    func showDisconnectedUI()
    func hideDisconnectedUI()
    func enableReconnectButton(_ enable: Bool)
}

class LiveSupportViewController: UIViewController {
    
    var presenter: LiveSupportPresenterProtocol!
    private let disconnectLabel = UILabel()
    private let tableView = UITableView()
    private let messageInputContainerView = UIView()
    private let inputTextField = UITextField()
    private let sendButton = UIButton(type: .system)
    
    private var messageInputContainerBottomConstraint: NSLayoutConstraint!
    private var reconnectButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setNavigatonBarView()
        setDisconnectLabel()
        setupTableView()
        setupInputComponents()
        setupKeyboardObservers()
        presenter.view = self
        presenter.viewDidLoad()
    }
    
    private func setNavigatonBarView() {
        title = "N11 Canlı Destek"
        reconnectButton = UIBarButtonItem(title: "Yeniden Bağlan",
                                          style: .plain,
                                          target: self,
                                          action: #selector(handleReconnectButton))
        reconnectButton.isEnabled = false
        navigationItem.rightBarButtonItem = reconnectButton
    }
    
    func setDisconnectLabel() {
        view.addSubview(disconnectLabel)
        disconnectLabel.text = "Canlı destek bağlantısı kesildi. \n Sağ üstteki Yeniden Bağlan butonuna tıklayarak sohbete bağlanabilirsiniz. "
        disconnectLabel.textColor = Constants.Colors.grayText
        disconnectLabel.font = UIFont.systemFont(ofSize: 18)
        disconnectLabel.backgroundColor = .clear
        disconnectLabel.numberOfLines = 0
        disconnectLabel.textAlignment = .center
        disconnectLabel.isHidden = true
        
        disconnectLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            disconnectLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            disconnectLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            disconnectLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10)
        ])
    }
    
    private func setupTableView() {
        view.addSubview(tableView)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableView.automaticDimension
        tableView.register(StepCell.self, forCellReuseIdentifier: "StepCell")
        tableView.register(MessageCell.self, forCellReuseIdentifier: "MessageCell")
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    private func setupInputComponents() {
        messageInputContainerView.backgroundColor = Constants.Colors.incomingMessageBackground
        messageInputContainerView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(messageInputContainerView)
        
        messageInputContainerBottomConstraint =
            messageInputContainerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        messageInputContainerBottomConstraint.isActive = true
        
        NSLayoutConstraint.activate([
            messageInputContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            messageInputContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            messageInputContainerView.heightAnchor.constraint(equalToConstant: 70),
            
            tableView.bottomAnchor.constraint(equalTo: messageInputContainerView.topAnchor)
        ])
        
        inputTextField.placeholder = "Mesajınızı yazın..."
        inputTextField.borderStyle = .roundedRect
        inputTextField.translatesAutoresizingMaskIntoConstraints = false
        
        sendButton.setTitle("Gönder", for: .normal)
        sendButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        sendButton.addTarget(self, action: #selector(handleSend), for: .touchUpInside)
        sendButton.setTitleColor(Constants.Colors.mainPurpleN11, for: .normal)
        
        messageInputContainerView.addSubview(inputTextField)
        messageInputContainerView.addSubview(sendButton)
        
        NSLayoutConstraint.activate([
            inputTextField.centerYAnchor.constraint(equalTo: messageInputContainerView.centerYAnchor),
            inputTextField.leadingAnchor.constraint(equalTo: messageInputContainerView.leadingAnchor, constant: 12),
            inputTextField.heightAnchor.constraint(equalToConstant: 40),
            
            sendButton.centerYAnchor.constraint(equalTo: messageInputContainerView.centerYAnchor),
            sendButton.trailingAnchor.constraint(equalTo: messageInputContainerView.trailingAnchor, constant: -12),
            sendButton.widthAnchor.constraint(equalToConstant: 80),
            
            inputTextField.trailingAnchor.constraint(equalTo: sendButton.leadingAnchor, constant: -8)
        ])
    }
    
    private func setupKeyboardObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleKeyboardWillShow),
                                               name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleKeyboardWillHide),
                                               name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc private func handleKeyboardWillShow(notification: Notification) {
        if let userInfo = notification.userInfo,
           let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
            let keyboardHeight = keyboardFrame.height
            messageInputContainerBottomConstraint.constant = -keyboardHeight + view.safeAreaInsets.bottom
            view.layoutIfNeeded()
        }
    }
    
    @objc private func handleKeyboardWillHide(notification: Notification) {
        messageInputContainerBottomConstraint.constant = 0
        view.layoutIfNeeded()
    }
    
    @objc private func handleSend() {
        presenter.didTapSend(text: inputTextField.text)
    }
    
    @objc private func handleReconnectButton() {
        presenter.didTapReconnect()
    }
}

// MARK: - LiveSupportViewProtocol
extension LiveSupportViewController: LiveSupportViewProtocol {
    func lastMessageSended(isSuccess: Bool) {
        DispatchQueue.main.async {
            // ux açısından statusa göre titreşim ekledim
            let notificationGenerator = UINotificationFeedbackGenerator()
            notificationGenerator.notificationOccurred(isSuccess ? .success : .error)
        }
    }
    
    func reloadData() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func clearTextField() {
        inputTextField.text = nil
    }
    
    func scrollToBottom() {
        let rows = presenter.numberOfRows()
        guard rows > 0 else { return }
        let indexPath = IndexPath(row: rows - 1, section: 0)
        DispatchQueue.main.async {
            self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
    }
    
    func showEndConversationAlert() {
        let alert = UIAlertController(title: "💬Sohbet Sonlandırıldı.",
                                      message: "Teşekkür ederiz, iyi günler",
                                      preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Kapat", style: .default) { [weak self] _ in
            self?.presenter.userClosedEndAlert()
        }
        alert.addAction(okAction)
        present(alert, animated: true)
    }
    
    func showDisconnectedUI() {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.tableView.isHidden = true
            self.inputTextField.isUserInteractionEnabled = false
            self.sendButton.isEnabled = false
            enableReconnectButton(true)
            disconnectLabel.isHidden = false
        }
    }
    
    func hideDisconnectedUI() {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            tableView.isHidden = false
            inputTextField.isUserInteractionEnabled = true
            sendButton.isEnabled = true
            enableReconnectButton(false)
            disconnectLabel.isHidden = true
        }
    }
    
    func enableReconnectButton(_ enable: Bool) {
        DispatchQueue.main.async {
            self.reconnectButton.isEnabled = enable
        }
    }
}

// MARK: - UITableViewDataSource, UITableViewDelegate
extension LiveSupportViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return presenter.numberOfRows()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = presenter.cellData(at: indexPath.row)
        if let step = item as? StepData {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "StepCell", for: indexPath) as? StepCell else {
                return UITableViewCell()
            }
            cell.configure(stepData: step, presenter: presenter)
            return cell
        } else if let message = item as? UserMessage {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell", for: indexPath) as? MessageCell else {
                return UITableViewCell()
            }
            cell.configure(message: message)
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
