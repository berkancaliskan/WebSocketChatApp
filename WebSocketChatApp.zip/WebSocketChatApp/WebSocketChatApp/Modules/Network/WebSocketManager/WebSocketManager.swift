//
//  WebSocketManager.swift
//  WebSocketChatApp
//
//  Created by Berkan Çalışkan on 16.12.2024.
//

import Foundation

protocol WebSocketManagerDelegate: AnyObject {
    func didReceiveMessage(_ text: String)
    func disconnected()
}

class WebSocketManager {
    
    static let shared = WebSocketManager()
    weak var delegate: WebSocketManagerDelegate?
    private var webSocketTask: URLSessionWebSocketTask?
    private let session = URLSession(configuration: .default)
    
    private init() {}
    
    func connectWebSocket() {
        let endpoint = Constants.URLs.webSocketEcho
        guard let url = URL(string: endpoint) else { return }
        webSocketTask = session.webSocketTask(with: url)
        webSocketTask?.resume()
        listenMessages()
        print("✅WebSocket connected")
    }
    
    private func listenMessages() {
        webSocketTask?.receive { [weak self] result in
            guard let self else { return }
            switch result {
            case .failure(let error):
                print("🔴WebSocket receive error: \(error)")
                self.disconnect()
            case .success(let message):
                switch message {
                case .string(let text):
                    self.delegate?.didReceiveMessage(text)
                case .data(let data):
                    if let str = String(data: data, encoding: .utf8) {
                        self.delegate?.didReceiveMessage(str)
                    }
                @unknown default:
                    break
                }
                self.listenMessages()
            }
        }
    }
    
    func sendMessage(_ text: String, completion: @escaping (Bool) -> Void) {
        let message = URLSessionWebSocketTask.Message.string(text)
        webSocketTask?.send(message) { error in
            if let error = error {
                print("🔴WebSocket send error: \(error)")
                completion(false)
            } else {
                completion(true)
            }
        }
    }
    
    func disconnect() {
        webSocketTask?.cancel(with: .goingAway, reason: nil)
        print("❎WebSocket disconnected")
        self.delegate?.disconnected()
    }
}
